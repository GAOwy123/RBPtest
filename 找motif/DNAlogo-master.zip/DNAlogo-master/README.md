# DNAlogo
# A smart mini application for generating DNA sequence logos
# Written in vb.net
# Used for creating DNA sequence logos with simple operation, and no programming knowldge needed
# By Yabin Guo, Sun Yat-sen University, China
